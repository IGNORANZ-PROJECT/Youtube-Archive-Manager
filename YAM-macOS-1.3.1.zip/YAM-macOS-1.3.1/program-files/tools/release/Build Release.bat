@echo off
setlocal EnableExtensions

set "SCRIPT_DIR=%~dp0"
set "BUILD_SCRIPT=%SCRIPT_DIR%build_release.py"
set "STATUS=1"

cd /d "%SCRIPT_DIR%"

if not exist "%BUILD_SCRIPT%" (
  echo build_release.py が見つかりません。
  goto finish
)

where py >nul 2>nul
if not errorlevel 1 (
  py -3 --version >nul 2>nul
  if not errorlevel 1 goto run_py
)

where python >nul 2>nul
if not errorlevel 1 (
  python --version >nul 2>nul
  if not errorlevel 1 goto run_python
)

echo Python 3.10 以上が必要です。
echo Windows に Python を入れてから、もう一度実行してください。
goto finish

:run_py
echo [YAM Build] launcher: py -3
call py -3 "%BUILD_SCRIPT%"
set "STATUS=%ERRORLEVEL%"
goto done

:run_python
echo [YAM Build] launcher: python
call python "%BUILD_SCRIPT%"
set "STATUS=%ERRORLEVEL%"
goto done

:done
echo.
if "%STATUS%"=="0" (
  echo ビルドが完了しました。
  echo Release フォルダ内の YAM-Windows-<version> を確認してください。
) else (
  echo ビルドに失敗しました。
  echo 上のメッセージを確認してください。
)

:finish
echo.
pause
exit /b %STATUS%
