# -*- mode: python ; coding: utf-8 -*-

import os
import sys
from pathlib import Path

from PyInstaller.building.build_main import Analysis, COLLECT, EXE, PYZ

if sys.platform == "darwin":
    from PyInstaller.building.osx import BUNDLE


BASE_DIR = Path(SPECPATH).parent.parent
ICON_FILE = os.environ.get("YAM_ICON_FILE", "").strip() or None
APP_VERSION = os.environ.get("YAM_APP_VERSION", "0.0.0").strip() or "0.0.0"

datas = [
    (str(BASE_DIR / "templates"), "templates"),
    (str(BASE_DIR / "static"), "static"),
    (str(BASE_DIR / "assets"), "assets"),
]

a = Analysis(
    [str(BASE_DIR / "launch_yam.py")],
    pathex=[str(BASE_DIR)],
    binaries=[],
    datas=datas,
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="YAM",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    icon=ICON_FILE,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="YAM",
)

if sys.platform == "darwin":
    app = BUNDLE(
        coll,
        name="YAM.app",
        icon=ICON_FILE,
        bundle_identifier="app.ignoranz.yam",
        info_plist={
            "CFBundleDisplayName": "YAM",
            "CFBundleName": "YAM",
            "CFBundleShortVersionString": APP_VERSION,
            "CFBundleVersion": APP_VERSION,
            "NSHighResolutionCapable": True,
        },
    )
