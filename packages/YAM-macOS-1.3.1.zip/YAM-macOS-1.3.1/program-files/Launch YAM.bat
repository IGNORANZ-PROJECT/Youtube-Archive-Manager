@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if exist "%~dp0dist\YAM\YAM.exe" goto run_dist_exe
if exist "%~dp0release\YAM\YAM.exe" goto run_release_exe
if exist "%~dp0YAM.exe" goto run_root_exe

where py >nul 2>nul
if not errorlevel 1 (
  py -3 --version >nul 2>nul
  if not errorlevel 1 goto run_py
)

where python >nul 2>nul
if not errorlevel 1 (
  python --version >nul 2>nul
  if not errorlevel 1 goto run_python
)

echo YAM.exe が見つからず、Python 3.10 以上も利用できません。
echo.
echo このフォルダにスタンドアロン版の YAM.exe が無い場合は、
echo 先に Python 3.10 以上をインストールしてください。
echo.
echo Python を入れた後に、もう一度 Launch YAM.bat を実行してください。
pause
exit /b 1

:run_dist_exe
"%~dp0dist\YAM\YAM.exe"
set "STATUS=%ERRORLEVEL%"
goto done

:run_release_exe
"%~dp0release\YAM\YAM.exe"
set "STATUS=%ERRORLEVEL%"
goto done

:run_root_exe
"%~dp0YAM.exe"
set "STATUS=%ERRORLEVEL%"
goto done

:run_py
py -3 "%~dp0launch_yam.py"
set "STATUS=%ERRORLEVEL%"
goto done

:run_python
python "%~dp0launch_yam.py"
set "STATUS=%ERRORLEVEL%"
goto done

:done
if not "%STATUS%"=="0" (
  echo.
  echo 起動に失敗しました。上のメッセージを確認してください。
  pause
)

exit /b %STATUS%
