import os
import re
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path
from typing import Optional

try:
    from PIL import Image
except ImportError:
    Image = None


SCRIPT_DIR = Path(__file__).resolve().parent
BASE_DIR = SCRIPT_DIR.parent.parent
RELEASE_ROOT_DIR = BASE_DIR / "Release"
DIST_DIR = RELEASE_ROOT_DIR / "dist"
BUILD_DIR = RELEASE_ROOT_DIR / "build"
PACKAGE_DIR = RELEASE_ROOT_DIR / "packages"
BUILD_ASSETS_DIR = RELEASE_ROOT_DIR / "build-assets"
SPEC_PATH = SCRIPT_DIR / "yam.spec"
ICON_SOURCE_PATH = BASE_DIR / "assets" / "icon.png"
SPEC_TEMPLATE = textwrap.dedent(
    """\
    # -*- mode: python ; coding: utf-8 -*-

    import os
    import sys
    from pathlib import Path

    from PyInstaller.building.build_main import Analysis, COLLECT, EXE, PYZ

    if sys.platform == "darwin":
        from PyInstaller.building.osx import BUNDLE


    BASE_DIR = Path(SPECPATH).parent.parent
    ICON_FILE = os.environ.get("YAM_ICON_FILE", "").strip() or None
    APP_VERSION = os.environ.get("YAM_APP_VERSION", "0.0.0").strip() or "0.0.0"

    datas = [
        (str(BASE_DIR / "templates"), "templates"),
        (str(BASE_DIR / "static"), "static"),
        (str(BASE_DIR / "assets"), "assets"),
    ]

    a = Analysis(
        [str(BASE_DIR / "launch_yam.py")],
        pathex=[str(BASE_DIR)],
        binaries=[],
        datas=datas,
        hiddenimports=["app", "flask", "jinja2", "werkzeug", "markupsafe", "click", "itsdangerous"],
        hookspath=[],
        hooksconfig={},
        runtime_hooks=[],
        excludes=[],
        noarchive=False,
    )
    pyz = PYZ(a.pure)

    exe = EXE(
        pyz,
        a.scripts,
        [],
        exclude_binaries=True,
        name="YAM",
        debug=False,
        bootloader_ignore_signals=False,
        strip=False,
        upx=False,
        console=False,
        icon=ICON_FILE,
    )

    coll = COLLECT(
        exe,
        a.binaries,
        a.datas,
        strip=False,
        upx=False,
        upx_exclude=[],
        name="YAM",
    )

    if sys.platform == "darwin":
        app = BUNDLE(
            coll,
            name="YAM.app",
            icon=ICON_FILE,
            bundle_identifier="app.ignoranz.yam",
            info_plist={
                "CFBundleDisplayName": "YAM",
                "CFBundleName": "YAM",
                "CFBundleShortVersionString": APP_VERSION,
                "CFBundleVersion": APP_VERSION,
                "NSHighResolutionCapable": True,
            },
        )
    """
)
PROGRAM_FILE_PATHS = [
    ".gitignore",
    "app.py",
    "launch_yam.py",
    "requirements.txt",
    "Launch YAM.bat",
    "Launch YAM.command",
    "assets",
    "static",
    "templates",
    "tools/release",
]
IGNORED_SOURCE_NAMES = {
    ".DS_Store",
    "Thumbs.db",
    "desktop.ini",
    "__pycache__",
    ".git",
    ".venv",
    ".pytest_cache",
    ".mypy_cache",
    ".pyinstaller",
}
IGNORED_SOURCE_SUFFIXES = {
    ".pyc",
    ".pyo",
}


def print_step(message: str) -> None:
    print(f"[YAM Build] {message}", flush=True)


def platform_label() -> str:
    if sys.platform == "darwin":
        return "macOS"
    if sys.platform.startswith("win"):
        return "Windows"
    return sys.platform


def load_app_version() -> str:
    app_path = BASE_DIR / "app.py"
    match = re.search(r'__version__\s*=\s*"([^"]+)"', app_path.read_text(encoding="utf-8"))
    return match.group(1) if match else "0.0.0"


def ensure_spec_file() -> None:
    current = None
    if SPEC_PATH.exists():
        try:
            current = SPEC_PATH.read_text(encoding="utf-8")
        except OSError:
            current = None
    if current == SPEC_TEMPLATE:
        return
    SPEC_PATH.parent.mkdir(parents=True, exist_ok=True)
    SPEC_PATH.write_text(SPEC_TEMPLATE, encoding="utf-8")
    action = "updated" if current is not None else "generated"
    print_step(f"spec {action}: {SPEC_PATH}")


def ensure_clean_artifacts() -> None:
    for path in (DIST_DIR, BUILD_DIR, PACKAGE_DIR, BUILD_ASSETS_DIR, RELEASE_ROOT_DIR / ".pyinstaller"):
        if path.exists():
            shutil.rmtree(path, ignore_errors=True)
    for path in (DIST_DIR, BUILD_DIR, PACKAGE_DIR, BUILD_ASSETS_DIR):
        path.mkdir(parents=True, exist_ok=True)


def create_icns_icon(target_path: Path) -> Optional[Path]:
    if sys.platform != "darwin" or not ICON_SOURCE_PATH.exists() or Image is None:
        return None

    image = Image.open(ICON_SOURCE_PATH)
    image.save(target_path, format="ICNS")
    return target_path if target_path.exists() else None


def create_ico_icon(target_path: Path) -> Optional[Path]:
    if not sys.platform.startswith("win") or not ICON_SOURCE_PATH.exists() or Image is None:
        return None

    image = Image.open(ICON_SOURCE_PATH)
    image.save(
        target_path,
        format="ICO",
        sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )
    return target_path if target_path.exists() else None


def prepare_icon_file() -> Optional[Path]:
    if not ICON_SOURCE_PATH.exists():
        return None

    try:
        if sys.platform == "darwin":
            return create_icns_icon(BUILD_ASSETS_DIR / "YAM.icns")
        if sys.platform.startswith("win"):
            return create_ico_icon(BUILD_ASSETS_DIR / "YAM.ico")
    except Exception as error:
        print_step(f"アイコン変換に失敗したため既定アイコンで続行します: {error}")
    return None


def build_env(icon_file: Optional[Path], version: str) -> dict[str, str]:
    env = os.environ.copy()
    env["YAM_APP_VERSION"] = version
    env["PYINSTALLER_CONFIG_DIR"] = str(RELEASE_ROOT_DIR / ".pyinstaller")
    if icon_file is not None:
        env["YAM_ICON_FILE"] = str(icon_file)
    return env


def run_pyinstaller(icon_file: Optional[Path], version: str) -> None:
    print_step("PyInstaller でスタンドアロン版をビルドしています...")
    subprocess.run(
        [
            sys.executable,
            "-m",
            "PyInstaller",
            "--noconfirm",
            "--distpath",
            str(DIST_DIR),
            "--workpath",
            str(BUILD_DIR),
            str(SPEC_PATH),
        ],
        cwd=BASE_DIR,
        env=build_env(icon_file, version),
        check=True,
    )


def find_built_target() -> Path:
    if sys.platform == "darwin":
        app_bundle = DIST_DIR / "YAM.app"
        if app_bundle.exists():
            return app_bundle
    folder = DIST_DIR / "YAM"
    if folder.exists():
        return folder
    exe_path = DIST_DIR / "YAM.exe"
    if exe_path.exists():
        return exe_path
    raise FileNotFoundError("PyInstaller の出力が見つかりません。")


def copytree_contents(source_dir: Path, target_dir: Path) -> None:
    target_dir.mkdir(parents=True, exist_ok=True)
    for child in source_dir.iterdir():
        destination = target_dir / child.name
        if child.is_dir():
            shutil.copytree(child, destination, dirs_exist_ok=True)
        else:
            shutil.copy2(child, destination)


def optional_doc_path(*relative_candidates: str) -> Optional[Path]:
    for relative_path in relative_candidates:
        candidate = BASE_DIR / relative_path
        if candidate.exists():
            return candidate
    return None


def copy_path(source: Path, target: Path) -> None:
    if source.is_dir():
        shutil.copytree(source, target, dirs_exist_ok=True, ignore=ignore_source_junk)
    else:
        if should_skip_path(source):
            return
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def should_skip_path(path: Path) -> bool:
    return path.name in IGNORED_SOURCE_NAMES or path.suffix.lower() in IGNORED_SOURCE_SUFFIXES


def ignore_source_junk(_dir_path: str, names: list[str]) -> list[str]:
    ignored_names: list[str] = []
    for name in names:
        if should_skip_path(Path(name)):
            ignored_names.append(name)
    return ignored_names


def cleanup_release_junk() -> None:
    for pattern in (".DS_Store", "Thumbs.db", "desktop.ini"):
        for path in RELEASE_ROOT_DIR.rglob(pattern):
            if path.is_file():
                path.unlink(missing_ok=True)


def stage_program_files(stage_dir: Path) -> None:
    source_dir = stage_dir / "program-files"
    source_dir.mkdir(parents=True, exist_ok=True)

    for relative_path in PROGRAM_FILE_PATHS:
        source_path = BASE_DIR / relative_path
        if not source_path.exists():
            continue
        copy_path(source_path, source_dir / relative_path)


def stage_release_bundle(built_target: Path, version: str) -> Path:
    stage_dir = PACKAGE_DIR / f"YAM-{platform_label()}-{version}"
    stage_dir.mkdir(parents=True, exist_ok=True)

    if built_target.is_dir() and built_target.suffix.lower() == ".app":
        shutil.copytree(built_target, stage_dir / built_target.name, dirs_exist_ok=True)
    elif built_target.is_dir():
        copytree_contents(built_target, stage_dir)
    else:
        shutil.copy2(built_target, stage_dir / built_target.name)

    readme_path = optional_doc_path("Release/README.md", "README.md")
    if readme_path is not None:
        shutil.copy2(readme_path, stage_dir / "README.md")

    license_path = optional_doc_path("Release/LICENSE", "LICENSE")
    if license_path is not None:
        shutil.copy2(license_path, stage_dir / "LICENSE")

    stage_program_files(stage_dir)
    return stage_dir


def create_release_archive(stage_dir: Path) -> Path:
    archive_base = PACKAGE_DIR / stage_dir.name
    archive_path = Path(shutil.make_archive(str(archive_base), "zip", root_dir=stage_dir.parent, base_dir=stage_dir.name))
    return archive_path


def cleanup_release_workspace() -> None:
    if sys.platform == "darwin":
        redundant_dir = DIST_DIR / "YAM"
        if redundant_dir.exists():
            shutil.rmtree(redundant_dir, ignore_errors=True)

    for path in (BUILD_DIR, BUILD_ASSETS_DIR, RELEASE_ROOT_DIR / ".pyinstaller"):
        if path.exists():
            shutil.rmtree(path, ignore_errors=True)
    cleanup_release_junk()


def main() -> int:
    try:
        import PyInstaller  # noqa: F401
    except ImportError:
        print_step("PyInstaller がありません。")
        print_step("まず `python -m pip install pyinstaller` を実行してください。")
        return 1
    if Image is None:
        print_step("Pillow がありません。")
        print_step("まず `python -m pip install pillow` を実行してください。")
        return 1

    version = load_app_version()
    ensure_spec_file()
    ensure_clean_artifacts()
    icon_file = prepare_icon_file()
    if icon_file is not None:
        print_step(f"icon: {icon_file}")

    run_pyinstaller(icon_file, version)
    built_target = find_built_target()
    stage_dir = stage_release_bundle(built_target, version)
    archive_path = create_release_archive(stage_dir)
    cleanup_release_workspace()

    print_step(f"built: {built_target}")
    print_step(f"release folder: {stage_dir}")
    print_step(f"release archive: {archive_path}")
    print_step("この zip を配布すれば、利用者側に Python は不要です。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
